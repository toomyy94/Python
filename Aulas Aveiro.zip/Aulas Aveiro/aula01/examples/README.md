# Bibliografia para aula 02.

* Slides e guião disponibilizados nesta pasta.
* [1, capítulo 2]
(Semelhante a [2, capítulo 2]).
* Extra: para aprender um pouco mais sobre erros e debugging,
recomenda-se [1, cap. 3].

# Trabalho para casa (Homework)

Ler e resolver os exercícios referentes a esta aula do livro recomendado [1].

[1] [How to Think Like a Computer Scientist: Interactive Edition](https://runestone.academy/runestone/static/thinkcspy/index.html)

[2] [Think Python 2e](http://greenteapress.com/wp/think-python-2e/)

