x = eval(input("qual é a temperatura em graus celsius?"))
y = 1.8*x + 32
print (y)

