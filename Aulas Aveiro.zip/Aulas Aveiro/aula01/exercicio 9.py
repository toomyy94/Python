x1= eval(input("x1?"))
x2=eval(input("x2?"))
y1=eval (input("y1?"))
y2=eval (input("y2?"))

d=sqrt((x2-x1)+(y2-y1))

print (d)
