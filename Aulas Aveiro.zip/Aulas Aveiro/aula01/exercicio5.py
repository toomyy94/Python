sec = int(input("segundos?"))

h = 
m = 
s =


print("{:02d}:{:02d}:{:02d}".format(h, m, s))
