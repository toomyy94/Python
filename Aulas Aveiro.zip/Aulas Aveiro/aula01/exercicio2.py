v1 = float(input ("qual é a velocidade em v1?"))
v2 = float(input ("qual é a velocidade em v2?"))
vm = v1+v2/2
print (vm)

