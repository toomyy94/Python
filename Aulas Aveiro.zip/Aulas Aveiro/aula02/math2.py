x1 = float(input("number? "))
x2 = float(input("number? "))
x3 = float(input ("number?"))
if x1==x2==x3:
	print ("equal numbers")

else:
	if x3>x2>x1:
		print (x3)
	if x2>x3>x1:
		print (x2)
	if x1>x2>x3
		print (x1)

