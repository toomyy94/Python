# Bibliografia para aula 01.

* Slides e guião disponibilizados nesta pasta.
* [1, capítulo 1]
(Semelhante a [2, capítulo 1]).

# Trabalho para casa (Homework)

Ler e resolver os exercícios referentes a esta aula do livro recomendado [1].

[1] [How to Think Like a Computer Scientist: Interactive Edition](https://runestone.academy/runestone/static/thinkcspy/index.html)

[2] [Think Python 2e](http://greenteapress.com/wp/think-python-2e/)

