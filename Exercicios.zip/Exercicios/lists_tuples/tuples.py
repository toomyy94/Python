tup = (4, 3, 2, 1)
print(tup)
print(tup[1])

print(tup[:2])
print(tup[1:3])

print("---------------------------------------")

for num in tup:
    print(num)