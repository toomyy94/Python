print( 2 > 3)
print( 2 < 3)
#a linha abaixo da erro porque estamos a atribuir e nao a comparar
#print( 2 = 3)
print( 2 == 3)
print( 2 >= 3)
print( 2 <= 3)
print( 2 != 3)

print("4 ultimos")
print(2 < 3 and 2 <= 3)
print(2 < 3 or 2 <= 3)
print(2 > 3 and 2 <= 3)
print(2 > 3 or 2 <= 3)





