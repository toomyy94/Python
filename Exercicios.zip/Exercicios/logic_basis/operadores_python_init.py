#isto e um comentario

"""
isto
sao
multilinhas
de
comentário
"""

add = 3 + 2
sub = 3 - 2
div = 3 / 2
mult= 3 * 2

pot = 2
pot **= 2
resto_da_divisao = 3 % 2

print(add, sub, div, mult)
print(pot, resto_da_divisao)