identificar os elementos do grupo (nome e número mecanográfico):

percentagem de trabalho realizada por cada aluno do grupo:
